package com.flutterflow.vertexaigeminidemo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
